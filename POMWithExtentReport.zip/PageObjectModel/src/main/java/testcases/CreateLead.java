package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods {
	
	@BeforeTest
	public void provideDetails() {
		testName = "CreateLead";
		testDescription = "Create lead with mandatory values";
		testAuthor = "Hari";
		testCategory = "Smoke";
		excelFileName = "CreateLead";

	}
	
	@Test(dataProvider="fetchData")
	public void runCreateLead(String username, String password, String fName,String lName,String company) throws InterruptedException, IOException {
		
		new LoginPage(driver,node)
		.enterUsername(username)
		.enterPassword(password)
		.clickLogin()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterFirstName(fName)
		.enterLastName(lName)
		.enterCompanyName(company)
		.clickCreateLead()
		.verifyFirstName();
		

	}

}
