package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginWithValidData extends ProjectSpecificMethods {
	
	@BeforeTest
	public void provideDetails() {
		testName = "LoginWithValidData";
		testDescription = "login with positive data";
		testAuthor = "Hari";
		testCategory = "Smoke";
		excelFileName = "LoginWithPositiveData";
	}
	
	@Test(dataProvider = "fetchData")
	public void loginAndLogout(String username, String password) throws InterruptedException, IOException {
	//	LoginPage lp = new LoginPage();
		
		new LoginPage(driver,node)
		.enterUsername(username)
		.enterPassword(password)
		.clickLogin();
		//.clickLogout();
		
	}

}
