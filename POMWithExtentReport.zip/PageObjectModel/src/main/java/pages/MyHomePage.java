package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;

public class MyHomePage extends ProjectSpecificMethods {
	
	public MyHomePage(ChromeDriver driver, ExtentTest test, ExtentTest node) {
		this.driver = driver;
		this.test = test;
		this.node = node;
	}

	public MyLeadsPage clickLeadsLink() {
		driver.findElementByLinkText("Leads").click();
		return new MyLeadsPage();
	}

}
