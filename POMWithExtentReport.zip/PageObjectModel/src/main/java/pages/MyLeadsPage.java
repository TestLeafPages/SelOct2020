package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class MyLeadsPage extends ProjectSpecificMethods {

	
	public CreateLeadPage clickCreateLeadLink() {
		driver.findElementByLinkText("Create Lead").click();
		return new CreateLeadPage();

	}
	
	public CreateLeadPage clickFindLeadLink() {
		driver.findElementByLinkText("Find Leads").click();
		return new CreateLeadPage();

	}
}
