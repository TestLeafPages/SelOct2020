package week7.day2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LearnToReadDataFromProperties {

	public static void main(String[] args) throws IOException {
		
		//set the file path for interaction
		FileInputStream fis = new FileInputStream("./src/test/resources/config.properties");
		
		//Create object for Properties
		Properties prop = new Properties();
		
		//load the properties
		prop.load(fis);
		
		//method to get the data from properties file
		String data1 = prop.getProperty("username");
		
		String data2 = prop.getProperty("password");
		
		System.out.println(data1);
		System.out.println(data2);
		
		
	}

}
